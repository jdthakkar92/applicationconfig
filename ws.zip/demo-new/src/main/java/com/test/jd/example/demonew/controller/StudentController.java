package com.test.jd.example.demonew.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.test.jd.example.demonew.request.StudentRequest;
import com.test.jd.example.demonew.response.StudentResponse;
import com.test.jd.example.demonew.service.StudentService;

@RestController
@RequestMapping("/api/student")
public class StudentController {
	@Autowired
	private StudentService studentService;
	
	@PostMapping("/create")
	public StudentResponse createStudent(@RequestBody StudentRequest studentRequest) {
		return studentService.createStudent(studentRequest);
	}
	
	@GetMapping("/getStudentById/{id}")
	public StudentResponse getStudent(@PathVariable long id) {
		return studentService.getStudent(id);
	}
}
