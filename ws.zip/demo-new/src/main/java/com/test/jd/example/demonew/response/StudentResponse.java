package com.test.jd.example.demonew.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@ToString
@Data
public class StudentResponse {

	private long studentId;
	private String name;
	private AddressResponse addressResponse;
}
