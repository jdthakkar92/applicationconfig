package com.test.jd.example.demonew.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.test.jd.example.demonew.entity.Student;
import com.test.jd.example.demonew.repository.StudentRepository;
import com.test.jd.example.demonew.request.StudentRequest;
import com.test.jd.example.demonew.response.AddressResponse;
import com.test.jd.example.demonew.response.StudentResponse;

@Service
public class StudentService {

	@Autowired
	private StudentRepository studentRepository;
	
	@Autowired
	private WebClient webClient;
	
	@Autowired
	private AddressCallService addressCallService;
	
	Logger logger = LoggerFactory.getLogger(StudentService.class);
	
	public StudentResponse createStudent(StudentRequest studentRequest) {
		Student student = new Student();
		student.setName(studentRequest.getName());
		student.setAddressId(studentRequest.getAddressId());
		student = studentRepository.save(student);
		StudentResponse studentResponse = new StudentResponse();
		studentResponse.setAddressResponse(getAddressDetails(student.getAddressId()));
		studentResponse.setName(student.getName());
		studentResponse.setStudentId(student.getId());
		return studentResponse;
	}
	
	public StudentResponse getStudent(Long id) {
		logger.info("student-service");
		Student student = studentRepository.findById(id).get();
		StudentResponse studentResponse = new StudentResponse();
		studentResponse.setAddressResponse(addressCallService.getAddressDetailsFeign(student.getAddressId()));
		studentResponse.setName(student.getName());
		studentResponse.setStudentId(student.getId());
		return studentResponse;
	}
	
	private AddressResponse getAddressDetails(Long addressId) {
		return webClient.get().uri("/getAddressById/"+addressId).retrieve().bodyToMono(AddressResponse.class).block();
	}
	
}
