package com.test.jd.example.demonew.repository;

import org.springframework.data.repository.CrudRepository;

import com.test.jd.example.demonew.entity.Student;

public interface StudentRepository extends CrudRepository<Student, Long>{

}
