package com.test.jd.example.demonew.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.test.jd.example.demonew.config.AddressFeignClient;
import com.test.jd.example.demonew.response.AddressResponse;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@Service
public class AddressCallService {
	static int cnt =0;
	@Autowired
	private AddressFeignClient addressFeignClient;

	@CircuitBreaker(name ="addressService", fallbackMethod = "fallbackMethodGetAddressDetailsFeign")
	public AddressResponse getAddressDetailsFeign(Long addressId) {
		cnt++;
		System.out.println(cnt);
		return addressFeignClient.getAddress(addressId);
	}
	
	public AddressResponse fallbackMethodGetAddressDetailsFeign(Long addressId, Throwable th) {
		return new AddressResponse();
	}
}
