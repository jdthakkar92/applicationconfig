package com.test.jd.example.demonew.config;
/*
 * import org.springframework.cloud.client.loadbalancer.LoadBalanced; import
 * org.springframework.cloud.loadbalancer.annotation.LoadBalancerClient; import
 * org.springframework.context.annotation.Bean;
 * 
 * import feign.Feign;
 * 
 * @LoadBalancerClient(value = "demo") public class AddressServiceLoadBalancer {
 * 
 * @LoadBalanced
 * 
 * @Bean public Feign.Builder feignBuilder() { return Feign.builder(); } }
 */
