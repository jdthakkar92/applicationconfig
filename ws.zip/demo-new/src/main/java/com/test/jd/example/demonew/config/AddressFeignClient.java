package com.test.jd.example.demonew.config;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.test.jd.example.demonew.response.AddressResponse;


//@FeignClient(url = "${address.service.url}" , value= "address-feign-client", path = "")
//@FeignClient(value= "demo", path = "/api/address")
@FeignClient(value= "demo-newzapi")
public interface AddressFeignClient {

	//@GetMapping("/getAddressById/{id}")
	@GetMapping("/demo/api/address/getAddressById/{id}")
	public AddressResponse getAddress(@PathVariable(value = "id") long id);
}
