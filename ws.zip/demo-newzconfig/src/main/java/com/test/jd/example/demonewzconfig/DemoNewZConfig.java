package com.test.jd.example.demonewzconfig;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.config.server.EnableConfigServer;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@SpringBootApplication
@EnableEurekaClient
@EnableConfigServer
public class DemoNewZConfig {
	public static void main(String[] args) {
		SpringApplication.run(DemoNewZConfig.class, args);
	}
}
