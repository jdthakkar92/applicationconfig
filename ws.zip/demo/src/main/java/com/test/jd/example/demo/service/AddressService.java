package com.test.jd.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.test.jd.example.demo.entity.Address;
import com.test.jd.example.demo.repository.AddressRepository;
import com.test.jd.example.demo.request.AddressRequest;
import com.test.jd.example.demo.response.AddressResponse;

@Service
public class AddressService {
	
	@Autowired
	private AddressRepository addressRepository;

	public AddressResponse createAddress(AddressRequest addressRequest) {
		Address address = new Address();
		address.setCity(addressRequest.getCity());
		address.setStreet(addressRequest.getStreet());
		address = addressRepository.save(address);
		AddressResponse addressResponse = new AddressResponse();
		addressResponse.setAddressId(address.getId());
		addressResponse.setCity(address.getCity());
		addressResponse.setStreet(address.getStreet());
		return addressResponse;
	}
	
	public AddressResponse getAddress(Long id) {
		Address address = addressRepository.findById(id).get();
		AddressResponse addressResponse = new AddressResponse();
		addressResponse.setAddressId(address.getId());
		addressResponse.setCity(address.getCity());
		addressResponse.setStreet(address.getStreet());
		return addressResponse;
	}
}
