package com.test.jd.example.demo.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.test.jd.example.demo.request.AddressRequest;
import com.test.jd.example.demo.response.AddressResponse;
import com.test.jd.example.demo.service.AddressService;

@RestController
@RequestMapping("/api/address")
public class AddressController {
	
	Logger logger = LoggerFactory.getLogger(AddressController.class);
	
	@Autowired
	private AddressService addressService;
	
	@PostMapping("/create")
	public AddressResponse createAddress(@RequestBody AddressRequest addressRequest) {
		return addressService.createAddress(addressRequest);
	}
	
	@GetMapping("/getAddressById/{id}")
	public AddressResponse getAddress(@PathVariable long id) {
		logger.info("address-controller");
		//System.out.println("Hello");
		return addressService.getAddress(id);
	}

}
